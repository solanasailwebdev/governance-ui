export enum GoverningTokenType {
  Community,
  Council,
}

export enum GovernanceType {
  Account,
  Program,
  Mint,
  Token,
}
